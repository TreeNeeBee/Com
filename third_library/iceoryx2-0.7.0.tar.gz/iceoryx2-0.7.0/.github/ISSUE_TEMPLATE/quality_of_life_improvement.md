---
name: Quality of Life Improvement
about: A cumbersome API/usage that shall be improved
title: ''
labels: 'enhancement'
assignees: ''

---

## (Code) Example Of Cumbersome API

Please take a moment to describe the specific issues you've encountered with
the current API. You can provide details either in a few sentences or with a
code example to highlight the pain points you've identified.

## Improvement Suggestion

We value your input! Please offer your proposed improvement, including a code
example if possible, to illustrate what the enhanced API should look like.
Your insights will help us streamline and enhance iceoryx2 API for a better
development experience.
