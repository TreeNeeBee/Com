# Changelog

* [unreleased](doc/release-notes/iceoryx2-unreleased.md)
* [v0.7.0](doc/release-notes/iceoryx2-v0.7.0.md)
* [v0.6.1](doc/release-notes/iceoryx2-v0.6.1.md)
* [v0.6.0](doc/release-notes/iceoryx2-v0.6.0.md)
* [v0.5.0](doc/release-notes/iceoryx2-v0.5.0.md)
* [v0.4.1](doc/release-notes/iceoryx2-v0.4.1.md)
* [v0.4.0](doc/release-notes/iceoryx2-v0.4.0.md)
* [v0.3.0](doc/release-notes/iceoryx2-v0.3.0.md)
* [v0.2.2](doc/release-notes/iceoryx2-v0.2.2.md)
* [v0.2.1](doc/release-notes/iceoryx2-v0.2.1.md)
