# Contributor Covenant Code of Conduct

We follow the
[Eclipse Foundation Community Code of Conduct](https://www.eclipse.org/org/documents/Community_Code_of_Conduct.php)
