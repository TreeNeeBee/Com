# iceoryx2 v0.6.1

## [v0.6.1](https://github.com/eclipse-iceoryx/iceoryx2/tree/v0.6.1)

[Full Changelog](https://github.com/eclipse-iceoryx/iceoryx2/compare/v0.6.0...v0.6.1)

### Bugfixes

<!--
    NOTE: Add new entries sorted by issue number to minimize the possibility of
    conflicts when merging.
-->

* Remove dependency to `iceoryx2-bb-elementary`
  [#759](https://github.com/eclipse-iceoryx/iceoryx2/issues/759)
