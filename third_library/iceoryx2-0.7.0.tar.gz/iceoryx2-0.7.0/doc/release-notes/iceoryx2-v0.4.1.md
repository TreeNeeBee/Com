# iceoryx2 v0.4.1

## [v0.4.1](https://github.com/eclipse-iceoryx/iceoryx2/tree/v0.4.1)

[Full Changelog](https://github.com/eclipse-iceoryx/iceoryx2/compare/v0.4.0...v0.4.1)

### Bugfixes

* Fix bug preventing `iox2` from being executed from any location
  [#409](https://github.com/eclipse-iceoryx/iceoryx2/issues/409)

## Thanks To All Contributors Of This Version

* [»orecham«](https://github.com/orecham)
