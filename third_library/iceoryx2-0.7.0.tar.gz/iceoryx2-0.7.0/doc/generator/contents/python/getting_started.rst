Getting Started
===============

.. toctree::

.. include:: ../../../../examples/python/README.md
   :parser: myst_parser.sphinx_

