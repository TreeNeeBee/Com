C-API Reference
===============

.. doxygenfile:: iceoryx2.h
   :project: iceoryx2
