Getting Started
===============

.. toctree::

.. include:: ../../../../examples/rust/README.md
   :parser: myst_parser.sphinx_
