**************
iceoryx2: Rust
**************

.. toctree::
   :maxdepth: 1

   getting_started
