# Welcome

Welcome to the C++ API reference for `iceoryx2`, the true zero-copy
inter-process communication library.

## Additional Resources

* [The `iceoryx2` Book](http://ekxide.github.io/iceoryx2-book)
* [Rust API Documentation](https://docs.rs/crate/iceoryx2/latest)
* [C API Documentation](http://eclipse-iceoryx.github.io/iceoryx2/c/latest)
* [Python API Documentation](http://eclipse-iceoryx.github.io/iceoryx2/python/latest)
